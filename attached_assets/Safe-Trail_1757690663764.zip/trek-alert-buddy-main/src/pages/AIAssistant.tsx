import React, { useState } from "react";
import { BackNavigation } from "@/components/Navigation";
import { PanicButton } from "@/components/PanicButton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Bot,
  Send,
  MapPin,
  Clock,
  Shield,
  Star,
  Phone,
  Navigation,
  Utensils,
  Building,
  Car,
} from "lucide-react";

const AIAssistant = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: "bot",
      content: "Hello! I'm your AI Travel Safety Assistant. I can help you with safe itineraries, trusted recommendations, and emergency guidance. How can I assist you today?",
      timestamp: "10:30 AM"
    },
    {
      id: 2,
      type: "user", 
      content: "I'm visiting Delhi for the first time. What are the safest areas to explore?",
      timestamp: "10:31 AM"
    },
    {
      id: 3,
      type: "bot",
      content: "Great choice! For first-time visitors to Delhi, I recommend these safe areas:\n\n🏛️ **Connaught Place** - Well-patrolled, tourist-friendly\n🌿 **India Gate area** - Open spaces, good security\n🏰 **Red Fort vicinity** - High tourist police presence\n🛍️ **Khan Market** - Safe shopping area\n\nAvoid: Paharganj late evenings, isolated areas near Old Delhi after dark.\n\nWould you like specific recommendations for any of these areas?",
      timestamp: "10:32 AM"
    }
  ]);

  const [inputMessage, setInputMessage] = useState("");

  const [quickSuggestions] = useState([
    { icon: MapPin, text: "Safe places to visit today", category: "safety" },
    { icon: Utensils, text: "Trusted restaurants nearby", category: "food" },
    { icon: Building, text: "Verified hotels in my area", category: "accommodation" },
    { icon: Car, text: "Reliable transport options", category: "transport" },
    { icon: Shield, text: "Emergency contacts for tourists", category: "emergency" },
    { icon: Clock, text: "Best times to visit monuments", category: "timing" }
  ]);

  const [safetyInsights] = useState([
    {
      title: "Current Safety Level",
      value: "High",
      description: "Your area has good security coverage",
      color: "text-safety"
    },
    {
      title: "Best Travel Time", 
      value: "Now - 6 PM",
      description: "Optimal visibility and crowd presence",
      color: "text-primary"
    },
    {
      title: "Nearby Help",
      value: "4 stations",
      description: "Police stations within 2km radius",
      color: "text-accent"
    }
  ]);

  const handleSendMessage = () => {
    if (inputMessage.trim()) {
      const newMessage = {
        id: messages.length + 1,
        type: "user" as const,
        content: inputMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages([...messages, newMessage]);
      setInputMessage("");
      
      // Simulate AI response
      setTimeout(() => {
        const botResponse = {
          id: messages.length + 2,
          type: "bot" as const,
          content: generateAIResponse(inputMessage),
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, botResponse]);
      }, 1000);
    }
  };

  const generateAIResponse = (input: string) => {
    const responses = [
      "Based on current safety data, I recommend visiting during daylight hours with proper precautions. Would you like specific safety tips for your destination?",
      "I've found several highly-rated and safe options for you. Let me share the verified recommendations with safety ratings.",
      "For your safety, I suggest these trusted alternatives. All recommendations are verified by our tourist safety network.",
      "Here are some AI-powered insights for your query. I've cross-referenced safety data and traveler reviews to give you the best options."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleQuickSuggestion = (suggestion: string) => {
    setInputMessage(suggestion);
  };

  return (
    <div className="min-h-screen bg-background">
      <BackNavigation title="AI Travel Assistant" />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-primary text-primary-foreground p-4 rounded-full mr-4">
              <Bot className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">AI Travel Assistant</h1>
              <p className="text-muted-foreground">Your intelligent safety companion for worry-free travel</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Chat Interface */}
          <div className="lg:col-span-3">
            <Card className="h-[600px] flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="h-5 w-5" />
                  AI Safety Assistant
                </CardTitle>
                <CardDescription>
                  Get personalized safety recommendations and travel guidance
                </CardDescription>
              </CardHeader>
              
              {/* Messages Area */}
              <CardContent className="flex-1 overflow-y-auto space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-4 rounded-lg ${
                      message.type === 'user' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-muted'
                    }`}>
                      <div className="whitespace-pre-wrap">{message.content}</div>
                      <div className={`text-xs mt-2 ${
                        message.type === 'user' 
                          ? 'text-primary-foreground/70' 
                          : 'text-muted-foreground'
                      }`}>
                        {message.timestamp}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>

              {/* Input Area */}
              <div className="p-4 border-t border-border">
                <div className="flex gap-2">
                  <Input
                    placeholder="Ask about safe places, trusted services, or emergency help..."
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="flex-1"
                  />
                  <Button onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                
                {/* Quick Suggestions */}
                <div className="flex flex-wrap gap-2 mt-3">
                  {quickSuggestions.slice(0, 3).map((suggestion, index) => {
                    const Icon = suggestion.icon;
                    return (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => handleQuickSuggestion(suggestion.text)}
                        className="text-xs"
                      >
                        <Icon className="h-3 w-3 mr-2" />
                        {suggestion.text}
                      </Button>
                    );
                  })}
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Real-time Safety Insights */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Safety Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {safetyInsights.map((insight, index) => (
                  <div key={index} className="text-center">
                    <div className={`text-2xl font-bold ${insight.color}`}>{insight.value}</div>
                    <div className="text-sm font-medium">{insight.title}</div>
                    <div className="text-xs text-muted-foreground">{insight.description}</div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {quickSuggestions.map((suggestion, index) => {
                  const Icon = suggestion.icon;
                  return (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-start text-left"
                      onClick={() => handleQuickSuggestion(suggestion.text)}
                    >
                      <Icon className="h-4 w-4 mr-2" />
                      {suggestion.text}
                    </Button>
                  );
                })}
              </CardContent>
            </Card>

            {/* AI Capabilities */}
            <Card>
              <CardHeader>
                <CardTitle>AI Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                    <MapPin className="h-3 w-3" />
                  </Badge>
                  <span className="text-sm">Location-based recommendations</span>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                    <Clock className="h-3 w-3" />
                  </Badge>
                  <span className="text-sm">Real-time safety updates</span>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                    <Star className="h-3 w-3" />
                  </Badge>
                  <span className="text-sm">Verified service ratings</span>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                    <Phone className="h-3 w-3" />
                  </Badge>
                  <span className="text-sm">Emergency assistance</span>
                </div>
              </CardContent>
            </Card>

            {/* Emergency Quick Access */}
            <Card className="border-emergency/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-emergency">
                  <Phone className="h-5 w-5" />
                  Emergency Help
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full bg-emergency hover:bg-emergency/90 text-emergency-foreground">
                  <Phone className="h-4 w-4 mr-2" />
                  Call Tourist Helpline
                </Button>
                <Button variant="outline" className="w-full">
                  <Navigation className="h-4 w-4 mr-2" />
                  Find Nearest Police
                </Button>
                <Button variant="outline" className="w-full">
                  <Building className="h-4 w-4 mr-2" />
                  Locate Embassy
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Floating Panic Button */}
      <PanicButton floating />
    </div>
  );
};

export default AIAssistant;