import React, { useState } from "react";
import { BackNavigation } from "@/components/Navigation";
import { PanicButton } from "@/components/PanicButton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertTriangle,
  DollarSign,
  MapPin,
  Clock,
  Users,
  Car,
  Camera,
  Ticket,
  Star,
  Flag,
  TrendingUp,
  Shield,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

const ScamAwareness = () => {
  const [selectedArea, setSelectedArea] = useState("Connaught Place, Delhi");
  const [reportForm, setReportForm] = useState({ scamType: "", description: "", location: "" });

  const [activeScams] = useState([
    {
      id: 1,
      title: "Fake Tourist Guide Scam",
      area: "India Gate, Delhi",
      severity: "high",
      reports: 23,
      timeframe: "Last 24 hours",
      description: "Individuals posing as official guides demanding upfront payment"
    },
    {
      id: 2,
      title: "Overpriced Taxi Meters",
      area: "Delhi Airport",
      severity: "medium", 
      reports: 15,
      timeframe: "Last 12 hours",
      description: "Taxi drivers using rigged meters or refusing to use meters"
    },
    {
      id: 3,
      title: "Counterfeit Ticket Sales",
      area: "Red Fort, Delhi",
      severity: "high",
      reports: 8,
      timeframe: "Last 6 hours",
      description: "Fake monument tickets being sold at inflated prices"
    }
  ]);

  const [verifiedPrices] = useState([
    {
      service: "Auto Rickshaw (per km)",
      price: "₹10-15",
      area: "Delhi NCR",
      verified: true,
      lastUpdated: "2 hours ago"
    },
    {
      service: "Taxi (per km)",
      price: "₹12-20",
      area: "Delhi NCR", 
      verified: true,
      lastUpdated: "1 hour ago"
    },
    {
      service: "Tourist Guide (per day)",
      price: "₹800-1500",
      area: "Delhi",
      verified: true,
      lastUpdated: "4 hours ago"
    },
    {
      service: "Red Fort Entry Ticket",
      price: "₹35 (Indians), ₹500 (Foreigners)",
      area: "Delhi",
      verified: true,
      lastUpdated: "6 hours ago"
    },
    {
      service: "India Gate Photography",
      price: "Free (No official charges)",
      area: "Delhi",
      verified: true,
      lastUpdated: "3 hours ago"
    },
    {
      service: "Airport Taxi to CP",
      price: "₹300-500",
      area: "Delhi Airport to Connaught Place",
      verified: true,
      lastUpdated: "30 mins ago"
    },
    {
      service: "Bottled Water (1L)",
      price: "₹20-25",
      area: "Tourist Areas",
      verified: true,
      lastUpdated: "1 hour ago"
    },
    {
      service: "Local SIM Card",
      price: "₹200-400 (prepaid)",
      area: "Delhi",
      verified: true,
      lastUpdated: "2 hours ago"
    }
  ]);

  const [scamTips] = useState([
    "Always ask for ID from anyone claiming to be an official guide",
    "Insist taxi drivers use the meter or agree on fare beforehand",
    "Buy tickets only from official counters or verified online platforms",
    "Be wary of 'special prices' or 'limited time offers' from strangers",
    "Cross-check prices with multiple vendors before purchasing",
    "Keep emergency contacts and Tourist Helpline (1363) handy"
  ]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high": return "bg-destructive text-destructive-foreground";
      case "medium": return "bg-warning text-warning-foreground";
      case "low": return "bg-primary text-primary-foreground";
      default: return "bg-secondary text-secondary-foreground";
    }
  };

  const handleReportScam = () => {
    if (reportForm.scamType && reportForm.description) {
      toast({
        title: "🚨 Scam Reported",
        description: "Thank you for reporting. This will help other travelers stay safe.",
      });
      setReportForm({ scamType: "", description: "", location: "" });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <BackNavigation title="Scam Awareness" />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-warning text-warning-foreground p-4 rounded-full mr-4">
              <AlertTriangle className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Scam Awareness</h1>
              <p className="text-muted-foreground">Stay alert, travel smart - protect yourself from tourist scams</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Active Scam Alerts */}
            <Card className="border-warning/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-warning">
                  <AlertTriangle className="h-5 w-5" />
                  Active Scam Alerts
                </CardTitle>
                <CardDescription>
                  Recent scam reports in your area - stay vigilant!
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeScams.map((scam) => (
                    <div key={scam.id} className="p-4 border border-border rounded-lg">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-lg">{scam.title}</h4>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {scam.area}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {scam.timeframe}
                            </span>
                            <span className="flex items-center gap-1">
                              <Flag className="h-3 w-3" />
                              {scam.reports} reports
                            </span>
                          </div>
                        </div>
                        <Badge className={getSeverityColor(scam.severity)}>
                          {scam.severity} risk
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{scam.description}</p>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Shield className="h-3 w-3 mr-2" />
                          Prevention Tips
                        </Button>
                        <Button size="sm" variant="outline">
                          <MapPin className="h-3 w-3 mr-2" />
                          Avoid Area
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Verified Price List */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Verified Price Guide for {selectedArea}
                </CardTitle>
                <CardDescription>
                  Official and community-verified pricing to prevent overcharging
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {verifiedPrices.map((item, index) => (
                    <div key={index} className="p-4 border border-border rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-medium">{item.service}</h4>
                        {item.verified && (
                          <Badge className="bg-safety text-safety-foreground text-xs">
                            Verified
                          </Badge>
                        )}
                      </div>
                      <div className="text-xl font-bold text-primary mb-1">{item.price}</div>
                      <div className="text-xs text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-3 w-3" />
                          {item.area}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Clock className="h-3 w-3" />
                          Updated {item.lastUpdated}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 p-3 bg-muted rounded-lg">
                  <p className="text-sm text-center">
                    💡 <strong>Pro Tip:</strong> Screenshot these prices to show vendors if they quote higher rates
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Report a Scam */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Flag className="h-5 w-5" />
                  Report a Scam
                </CardTitle>
                <CardDescription>
                  Help fellow travelers by reporting scam attempts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Type of Scam</label>
                  <Input
                    placeholder="e.g., Fake guide, overpriced taxi, counterfeit tickets"
                    value={reportForm.scamType}
                    onChange={(e) => setReportForm({ ...reportForm, scamType: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Location</label>
                  <Input
                    placeholder="Where did this happen?"
                    value={reportForm.location}
                    onChange={(e) => setReportForm({ ...reportForm, location: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Description</label>
                  <Textarea
                    placeholder="Describe the scam attempt in detail..."
                    value={reportForm.description}
                    onChange={(e) => setReportForm({ ...reportForm, description: e.target.value })}
                  />
                </div>
                <Button onClick={handleReportScam} className="w-full">
                  <Flag className="h-4 w-4 mr-2" />
                  Submit Report
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Scam Prevention Tips */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Prevention Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {scamTips.map((tip, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <Badge variant="secondary" className="w-6 h-6 rounded-full flex items-center justify-center text-xs mt-1">
                        {index + 1}
                      </Badge>
                      <span className="text-sm">{tip}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Common Scam Types */}
            <Card>
              <CardHeader>
                <CardTitle>Common Tourist Scams</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                  <Users className="h-4 w-4 text-warning" />
                  <span className="text-sm">Fake Tourism Officials</span>
                </div>
                <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                  <Car className="h-4 w-4 text-warning" />
                  <span className="text-sm">Rigged Taxi Meters</span>
                </div>
                <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                  <Camera className="h-4 w-4 text-warning" />
                  <span className="text-sm">Photo Scams</span>
                </div>
                <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                  <Ticket className="h-4 w-4 text-warning" />
                  <span className="text-sm">Counterfeit Tickets</span>
                </div>
                <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                  <DollarSign className="h-4 w-4 text-warning" />
                  <span className="text-sm">Inflated Prices</span>
                </div>
              </CardContent>
            </Card>

            {/* Emergency Contacts */}
            <Card>
              <CardHeader>
                <CardTitle>If You're Scammed</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  📞 Tourist Helpline: 1363
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  🚔 Local Police: 100
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  💳 Report Financial Fraud
                </Button>
                <div className="text-xs text-muted-foreground mt-2">
                  <p>• Document everything (photos, receipts)</p>
                  <p>• Report immediately to authorities</p>
                  <p>• Inform your bank if cards are involved</p>
                </div>
              </CardContent>
            </Card>

            {/* Community Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Community Impact
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">1,847</div>
                  <div className="text-sm text-muted-foreground">Scams Prevented</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-safety">₹12.5L</div>
                  <div className="text-sm text-muted-foreground">Money Saved</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-accent">456</div>
                  <div className="text-sm text-muted-foreground">Active Reporters</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Floating Panic Button */}
      <PanicButton floating />
    </div>
  );
};

export default ScamAwareness;