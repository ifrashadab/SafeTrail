import React, { useState } from "react";
import { BackNavigation } from "@/components/Navigation";
import { PanicButton } from "@/components/PanicButton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Phone,
  MapPin,
  Clock,
  Users,
  Shield,
  Zap,
  Heart,
  Navigation as NavigationIcon,
  AlertTriangle,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

const EmergencyPanel = () => {
  const [emergencyContacts, setEmergencyContacts] = useState([
    { name: "Local Police", number: "100", type: "police" },
    { name: "Ambulance", number: "108", type: "medical" },
    { name: "Tourist Helpline", number: "1363", type: "tourist" },
    { name: "Fire Brigade", number: "101", type: "fire" },
  ]);

  const [customContact, setCustomContact] = useState({ name: "", number: "" });

  const handleQuickCall = (number: string, service: string) => {
    toast({
      title: `📞 Calling ${service}`,
      description: `Initiating call to ${number}...`,
    });
  };

  const addCustomContact = () => {
    if (customContact.name && customContact.number) {
      setEmergencyContacts([
        ...emergencyContacts,
        { ...customContact, type: "custom" }
      ]);
      setCustomContact({ name: "", number: "" });
      toast({
        title: "✅ Contact Added",
        description: "Emergency contact has been added successfully.",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <BackNavigation title="Emergency Panel" />
      
      <div className="container mx-auto px-4 py-8">
        {/* Emergency Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <PanicButton className="mr-4" />
            <div>
              <h1 className="text-3xl font-bold text-emergency">🚨 Emergency Panel</h1>
              <p className="text-muted-foreground">Immediate assistance and emergency contacts</p>
            </div>
          </div>
        </div>

        {/* Emergency Features */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="border-emergency/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-emergency">
                <Zap className="h-5 w-5" />
                Panic Button Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                  1
                </Badge>
                <span>Instant alert to all emergency services</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                  2
                </Badge>
                <span>Live location sharing activated</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                  3
                </Badge>
                <span>Emergency contacts automatically notified</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                  4
                </Badge>
                <span>Incident room created for responders</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <NavigationIcon className="h-5 w-5" />
                Current Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  Location Services
                </span>
                <Badge className="bg-safety text-safety-foreground">Active</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-primary" />
                  Emergency Mode
                </span>
                <Badge variant="secondary">Standby</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-primary" />
                  Nearby Helpers
                </span>
                <Badge className="bg-primary text-primary-foreground">12 Available</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-primary" />
                  Last Check-in
                </span>
                <span className="text-sm text-muted-foreground">2 mins ago</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Emergency Contacts */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="h-5 w-5" />
              Emergency Contacts
            </CardTitle>
            <CardDescription>
              Quick access to emergency services and your personal contacts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {emergencyContacts.map((contact, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 border border-border rounded-lg"
                >
                  <div>
                    <h4 className="font-medium">{contact.name}</h4>
                    <p className="text-sm text-muted-foreground">{contact.number}</p>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleQuickCall(contact.number, contact.name)}
                    className="bg-emergency hover:bg-emergency/90 text-emergency-foreground"
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Call
                  </Button>
                </div>
              ))}
            </div>

            {/* Add Custom Contact */}
            <div className="border-t border-border pt-6">
              <h4 className="font-medium mb-4">Add Personal Emergency Contact</h4>
              <div className="flex gap-4">
                <div className="flex-1">
                  <Label htmlFor="contactName">Name</Label>
                  <Input
                    id="contactName"
                    placeholder="Contact name"
                    value={customContact.name}
                    onChange={(e) => setCustomContact({ ...customContact, name: e.target.value })}
                  />
                </div>
                <div className="flex-1">
                  <Label htmlFor="contactNumber">Phone Number</Label>
                  <Input
                    id="contactNumber"
                    placeholder="+91 XXXXXXXXXX"
                    value={customContact.number}
                    onChange={(e) => setCustomContact({ ...customContact, number: e.target.value })}
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={addCustomContact}>Add Contact</Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Safety Tips */}
        <Card className="border-warning/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-warning">
              <AlertTriangle className="h-5 w-5" />
              Emergency Safety Tips
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h4 className="font-medium">Before Emergency:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• Keep your phone charged</li>
                  <li>• Share itinerary with trusted contacts</li>
                  <li>• Know your location landmarks</li>
                  <li>• Keep important documents handy</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">During Emergency:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• Stay calm and use panic button</li>
                  <li>• Provide clear location details</li>
                  <li>• Follow responder instructions</li>
                  <li>• Keep communication lines open</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Floating Panic Button */}
      <PanicButton floating />
    </div>
  );
};

export default EmergencyPanel;