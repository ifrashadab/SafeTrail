import React, { useState } from "react";
import { BackNavigation } from "@/components/Navigation";
import { PanicButton } from "@/components/PanicButton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { QRCodeSVG } from "qrcode.react";
import {
  CreditCard,
  Shield,
  Calendar,
  MapPin,
  Plane,
  Check,
  Clock,
  Download,
  Share,
  Smartphone,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

const DigitalTouristID = () => {
  const [touristID] = useState({
    id: "TID-2024-IND-789456123",
    name: "Rahul Sharma",
    nationality: "Indian",
    issueDate: "2024-01-15",
    validUntil: "2024-02-15",
    travelerType: "Domestic Tourist",
    verificationLevel: "Verified",
    blockchainHash: "0x4f8a9b2c1e6d3a7f9b2c8e4a6d1f3b7c9e2a4f8b1d6c3e9a7f2b8c4e6a1d3f9b",
    triggers: [
      { type: "Flight Booking", source: "IndiGo 6E-234", date: "2024-01-15" },
      { type: "Hotel Check-in", source: "Taj Palace Mumbai", date: "2024-01-15" },
    ],
    status: "Active"
  });

  const handleDownloadID = () => {
    toast({
      title: "📱 ID Downloaded",
      description: "Your Digital Tourist ID has been saved to your device.",
    });
  };

  const handleShareID = () => {
    toast({
      title: "🔗 ID Shared",
      description: "Digital Tourist ID link has been copied to clipboard.",
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active": return "bg-safety text-safety-foreground";
      case "Expired": return "bg-destructive text-destructive-foreground";
      case "Pending": return "bg-warning text-warning-foreground";
      default: return "bg-secondary text-secondary-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <BackNavigation title="Digital Tourist ID" />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-primary text-primary-foreground p-4 rounded-full mr-4">
              <CreditCard className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Digital Tourist ID</h1>
              <p className="text-muted-foreground">Blockchain-based travel identification</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main ID Card */}
          <div className="lg:col-span-2">
            <Card className="mb-6 bg-gradient-to-br from-primary to-primary-dark text-primary-foreground">
              <CardContent className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-2xl font-bold mb-1">🇮🇳 Digital Tourist ID</h2>
                    <p className="text-primary-foreground/80">Government of India</p>
                  </div>
                  <Badge className={getStatusColor(touristID.status)}>
                    {touristID.status}
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <div className="space-y-4">
                      <div>
                        <p className="text-primary-foreground/70 text-sm">Full Name</p>
                        <p className="font-semibold text-lg">{touristID.name}</p>
                      </div>
                      <div>
                        <p className="text-primary-foreground/70 text-sm">Tourist ID</p>
                        <p className="font-mono text-sm">{touristID.id}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-primary-foreground/70 text-sm">Nationality</p>
                          <p className="font-medium">{touristID.nationality}</p>
                        </div>
                        <div>
                          <p className="text-primary-foreground/70 text-sm">Type</p>
                          <p className="font-medium">{touristID.travelerType}</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-primary-foreground/70 text-sm">Issued</p>
                          <p className="font-medium">{touristID.issueDate}</p>
                        </div>
                        <div>
                          <p className="text-primary-foreground/70 text-sm">Valid Until</p>
                          <p className="font-medium">{touristID.validUntil}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-center justify-center">
                    <div className="bg-white p-4 rounded-lg mb-4">
                      <QRCodeSVG 
                        value={`https://tourist-id.gov.in/verify/${touristID.id}`}
                        size={120}
                        level="H"
                      />
                    </div>
                    <p className="text-primary-foreground/80 text-xs text-center">
                      Scan to verify authenticity
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-primary-foreground/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4" />
                      <span className="text-sm">Blockchain Verified</span>
                    </div>
                    <div className="text-xs font-mono">
                      Hash: {touristID.blockchainHash.substring(0, 16)}...
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* ID Generation History */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  ID Generation History
                </CardTitle>
                <CardDescription>
                  How your Digital Tourist ID was automatically created
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {touristID.triggers.map((trigger, index) => (
                    <div key={index} className="flex items-start gap-4 p-4 border border-border rounded-lg">
                      <div className="bg-primary text-primary-foreground p-2 rounded-full">
                        {trigger.type.includes("Flight") ? (
                          <Plane className="h-4 w-4" />
                        ) : (
                          <MapPin className="h-4 w-4" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{trigger.type}</h4>
                        <p className="text-muted-foreground">{trigger.source}</p>
                        <p className="text-sm text-muted-foreground">{trigger.date}</p>
                      </div>
                      <Check className="h-5 w-5 text-safety" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button onClick={handleDownloadID} className="w-full">
                  <Download className="h-4 w-4 mr-2" />
                  Download ID
                </Button>
                <Button onClick={handleShareID} variant="outline" className="w-full">
                  <Share className="h-4 w-4 mr-2" />
                  Share ID
                </Button>
                <Button variant="outline" className="w-full">
                  <Smartphone className="h-4 w-4 mr-2" />
                  Add to Wallet
                </Button>
              </CardContent>
            </Card>

            {/* Verification Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Verification Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Identity Verified</span>
                  <Check className="h-5 w-5 text-safety" />
                </div>
                <div className="flex items-center justify-between">
                  <span>Blockchain Recorded</span>
                  <Check className="h-5 w-5 text-safety" />
                </div>
                <div className="flex items-center justify-between">
                  <span>Government Approved</span>
                  <Check className="h-5 w-5 text-safety" />
                </div>
                <div className="flex items-center justify-between">
                  <span>Emergency Access</span>
                  <Check className="h-5 w-5 text-safety" />
                </div>
              </CardContent>
            </Card>

            {/* Auto-Generation Triggers */}
            <Card>
              <CardHeader>
                <CardTitle>Auto-Generation</CardTitle>
                <CardDescription>
                  Your ID is automatically created when you:
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <Plane className="h-4 w-4 text-primary" />
                  <span className="text-sm">Book flights or cross immigration</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="h-4 w-4 text-primary" />
                  <span className="text-sm">Check into registered hotels</span>
                </div>
                <div className="flex items-center gap-3">
                  <CreditCard className="h-4 w-4 text-primary" />
                  <span className="text-sm">Use FASTag at toll gates</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="h-4 w-4 text-primary" />
                  <span className="text-sm">Book train tickets via IRCTC</span>
                </div>
              </CardContent>
            </Card>

            {/* Privacy & Security */}
            <Card>
              <CardHeader>
                <CardTitle>Privacy & Security</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm text-muted-foreground space-y-2">
                  <p>• End-to-end encrypted data</p>
                  <p>• Tamper-proof blockchain records</p>
                  <p>• Auto-deleted after trip completion</p>
                  <p>• Location shared only during emergencies</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Floating Panic Button */}
      <PanicButton floating />
    </div>
  );
};

export default DigitalTouristID;