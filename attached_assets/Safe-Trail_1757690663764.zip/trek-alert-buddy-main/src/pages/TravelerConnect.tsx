import React, { useState } from "react";
import { BackNavigation } from "@/components/Navigation";
import { PanicButton } from "@/components/PanicButton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Users,
  MapPin,
  Clock,
  Star,
  MessageCircle,
  UserPlus,
  Shield,
  Heart,
  Gift,
  Search,
  Filter,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

const TravelerConnect = () => {
  const [selectedFilter, setSelectedFilter] = useState("nearby");
  const [searchQuery, setSearchQuery] = useState("");

  const [nearbyTravelers] = useState([
    {
      id: 1,
      name: "Priya Sharma",
      location: "India Gate, Delhi",
      distance: "150m",
      safetyRating: 4.8,
      joinedGroups: 3,
      lastActive: "2 mins ago",
      travelerType: "Solo Female",
      interests: ["Photography", "History"],
      helpfulActions: 12
    },
    {
      id: 2, 
      name: "John Williams",
      location: "Connaught Place, Delhi",
      distance: "400m",
      safetyRating: 4.5,
      joinedGroups: 2,
      lastActive: "5 mins ago", 
      travelerType: "International",
      interests: ["Food", "Culture"],
      helpfulActions: 8
    },
    {
      id: 3,
      name: "Rahul & Family",
      location: "Red Fort, Delhi",
      distance: "1.2km",
      safetyRating: 4.9,
      joinedGroups: 1,
      lastActive: "10 mins ago",
      travelerType: "Family Group",
      interests: ["Monuments", "Shopping"],
      helpfulActions: 15
    }
  ]);

  const [travelGroups] = useState([
    {
      id: 1,
      name: "Delhi Heritage Walk",
      members: 8,
      category: "Sightseeing",
      location: "Old Delhi",
      time: "Tomorrow, 9:00 AM",
      safetyLevel: "High",
      description: "Guided heritage walk through historical Old Delhi"
    },
    {
      id: 2,
      name: "Safe Solo Travelers - Delhi",
      members: 24,
      category: "Safety Network",
      location: "Delhi NCR",
      time: "Active 24/7",
      safetyLevel: "Very High", 
      description: "Emergency support network for solo travelers"
    },
    {
      id: 3,
      name: "Photography Meetup",
      members: 12,
      category: "Interest Group",
      location: "Lotus Temple",
      time: "Today, 4:00 PM",
      safetyLevel: "High",
      description: "Photography enthusiasts exploring Delhi landmarks"
    }
  ]);

  const [helpRequests] = useState([
    {
      id: 1,
      requester: "Lisa Chen",
      request: "Need help finding authentic local food in CP",
      location: "Connaught Place",
      timeAgo: "5 mins ago",
      category: "Local Info",
      urgency: "low"
    },
    {
      id: 2,
      requester: "Ahmed Hassan",
      request: "Lost wallet, need help contacting police",
      location: "Khan Market",
      timeAgo: "12 mins ago",
      category: "Emergency Help",
      urgency: "high"
    },
    {
      id: 3,
      requester: "Maria Santos",
      request: "Looking for travel buddy to Agra tomorrow",
      location: "New Delhi Railway Station",
      timeAgo: "20 mins ago",
      category: "Travel Companion",
      urgency: "medium"
    }
  ]);

  const getSafetyLevelColor = (level: string) => {
    switch (level) {
      case "Very High": return "bg-safety text-safety-foreground";
      case "High": return "bg-primary text-primary-foreground";
      case "Medium": return "bg-warning text-warning-foreground";
      default: return "bg-secondary text-secondary-foreground";
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "high": return "border-l-4 border-l-destructive";
      case "medium": return "border-l-4 border-l-warning";
      case "low": return "border-l-4 border-l-primary";
      default: return "border-l-4 border-l-muted";
    }
  };

  const handleConnectTraveler = (name: string) => {
    toast({
      title: "🤝 Connection Request Sent",
      description: `Your connection request to ${name} has been sent.`,
    });
  };

  const handleJoinGroup = (groupName: string) => {
    toast({
      title: "✅ Joined Group",
      description: `You've successfully joined "${groupName}".`,
    });
  };

  const handleHelpRequest = (requesterName: string) => {
    toast({
      title: "💙 Help Offered",
      description: `Your offer to help ${requesterName} has been sent.`,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <BackNavigation title="Traveler Connect" />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-accent text-accent-foreground p-4 rounded-full mr-4">
              <Users className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Traveler Connect</h1>
              <p className="text-muted-foreground">Connect with fellow travelers for safety and community</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search and Filter */}
            <Card>
              <CardContent className="p-4">
                <div className="flex gap-4 mb-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Search travelers, groups, or locations..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <Button variant="outline" size="icon">
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex gap-2">
                  {["nearby", "groups", "help-requests"].map((filter) => (
                    <Button
                      key={filter}
                      variant={selectedFilter === filter ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedFilter(filter)}
                    >
                      <Filter className="h-3 w-3 mr-2" />
                      {filter.replace("-", " ").replace(/\b\w/g, l => l.toUpperCase())}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Nearby Travelers */}
            {selectedFilter === "nearby" && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5" />
                    Nearby Travelers
                  </CardTitle>
                  <CardDescription>
                    Connect with travelers near your location for safety and companionship
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {nearbyTravelers.map((traveler) => (
                      <div key={traveler.id} className="p-4 border border-border rounded-lg">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-3">
                            <Avatar>
                              <AvatarFallback>{traveler.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <h4 className="font-medium">{traveler.name}</h4>
                              <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-3 w-3" />
                                  {traveler.location} ({traveler.distance})
                                </span>
                                <span className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  {traveler.lastActive}
                                </span>
                              </div>
                              <div className="flex items-center gap-2 mt-2">
                                <Badge variant="outline">{traveler.travelerType}</Badge>
                                <div className="flex items-center gap-1">
                                  <Star className="h-3 w-3 text-warning fill-current" />
                                  <span className="text-xs">{traveler.safetyRating}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Heart className="h-3 w-3 text-primary" />
                                  <span className="text-xs">{traveler.helpfulActions} helpful</span>
                                </div>
                              </div>
                              <div className="mt-2">
                                <span className="text-xs text-muted-foreground">Interests: </span>
                                {traveler.interests.map((interest, idx) => (
                                  <Badge key={idx} variant="secondary" className="text-xs mr-1">
                                    {interest}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <MessageCircle className="h-3 w-3 mr-2" />
                              Chat
                            </Button>
                            <Button size="sm" onClick={() => handleConnectTraveler(traveler.name)}>
                              <UserPlus className="h-3 w-3 mr-2" />
                              Connect
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Travel Groups */}
            {selectedFilter === "groups" && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Travel Groups
                  </CardTitle>
                  <CardDescription>
                    Join safety networks and interest-based travel groups
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {travelGroups.map((group) => (
                      <div key={group.id} className="p-4 border border-border rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h4 className="font-medium text-lg">{group.name}</h4>
                            <p className="text-sm text-muted-foreground mt-1">{group.description}</p>
                          </div>
                          <Badge className={getSafetyLevelColor(group.safetyLevel)}>
                            {group.safetyLevel} Safety
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                          <div>
                            <span className="text-muted-foreground">Members:</span>
                            <div className="font-medium">{group.members}</div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Category:</span>
                            <div className="font-medium">{group.category}</div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Location:</span>
                            <div className="font-medium">{group.location}</div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Time:</span>
                            <div className="font-medium">{group.time}</div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" onClick={() => handleJoinGroup(group.name)}>
                            <UserPlus className="h-3 w-3 mr-2" />
                            Join Group
                          </Button>
                          <Button size="sm" variant="outline">
                            <MessageCircle className="h-3 w-3 mr-2" />
                            View Details
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Help Requests */}
            {selectedFilter === "help-requests" && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="h-5 w-5" />
                    Help Requests
                  </CardTitle>
                  <CardDescription>
                    Offer help to fellow travelers in need - earn community rewards
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {helpRequests.map((request) => (
                      <div key={request.id} className={`p-4 border border-border rounded-lg ${getUrgencyColor(request.urgency)}`}>
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h4 className="font-medium">{request.requester}</h4>
                              <Badge variant={request.urgency === "high" ? "destructive" : request.urgency === "medium" ? "default" : "secondary"}>
                                {request.category}
                              </Badge>
                            </div>
                            <p className="text-sm mb-2">{request.request}</p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <MapPin className="h-3 w-3" />
                                {request.location}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {request.timeAgo}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" onClick={() => handleHelpRequest(request.requester)}>
                            <Heart className="h-3 w-3 mr-2" />
                            Offer Help
                          </Button>
                          <Button size="sm" variant="outline">
                            <MessageCircle className="h-3 w-3 mr-2" />
                            Message
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Community Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Your Community Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">4.8</div>
                  <div className="text-sm text-muted-foreground">Safety Rating</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-safety">23</div>
                  <div className="text-sm text-muted-foreground">Helpful Actions</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-accent">156</div>
                  <div className="text-sm text-muted-foreground">Community Points</div>
                </div>
              </CardContent>
            </Card>

            {/* Rewards & Incentives */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gift className="h-5 w-5" />
                  Rewards Program
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <div className="font-medium text-sm">Next Reward</div>
                  <div className="text-xs text-muted-foreground">Help 5 more travelers to unlock "Community Hero" badge</div>
                  <div className="mt-2 bg-background rounded-full h-2">
                    <div className="bg-primary rounded-full h-2 w-3/5"></div>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>🏆 Earn badges for helping others</p>
                  <p>💰 Get discounts at partner venues</p>
                  <p>⭐ Higher safety ratings increase trust</p>
                  <p>🎁 Exclusive community events access</p>
                </div>
              </CardContent>
            </Card>

            {/* Safety Guidelines */}
            <Card>
              <CardHeader>
                <CardTitle>Community Guidelines</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm space-y-2">
                  <p className="flex items-start gap-2">
                    <Shield className="h-4 w-4 text-primary mt-0.5" />
                    <span>Always meet in public places</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <Users className="h-4 w-4 text-primary mt-0.5" />
                    <span>Verify traveler profiles before connecting</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <Heart className="h-4 w-4 text-primary mt-0.5" />
                    <span>Be genuinely helpful and respectful</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-primary mt-0.5" />
                    <span>Share real-time location with trusted contacts</span>
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Users className="h-4 w-4 mr-2" />
                  Create New Group
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Heart className="h-4 w-4 mr-2" />
                  Post Help Request
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Open Community Chat
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Floating Panic Button */}
      <PanicButton floating />
    </div>
  );
};

export default TravelerConnect;