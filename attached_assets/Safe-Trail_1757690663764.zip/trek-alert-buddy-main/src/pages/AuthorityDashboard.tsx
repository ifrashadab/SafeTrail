import React, { useState } from "react";
import { BackNavigation } from "@/components/Navigation";
import { PanicButton } from "@/components/PanicButton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Settings,
  Users,
  MapPin,
  AlertTriangle,
  Clock,
  TrendingUp,
  Search,
  Filter,
  Download,
  Eye,
  FileText,
  Shield,
  Zap,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

const AuthorityDashboard = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTimeframe, setSelectedTimeframe] = useState("24h");

  const [realTimeStats] = useState({
    activeTourists: 1247,
    emergencyAlerts: 3,
    missingPersons: 0,
    safeZoneViolations: 7,
    avgResponseTime: "4.2 mins",
    hotspotAreas: ["Connaught Place", "India Gate", "Red Fort"]
  });

  const [touristClusters] = useState([
    {
      area: "Connaught Place",
      count: 324,
      density: "High",
      safetyLevel: "Good",
      alerts: 0,
      coordinates: { lat: 28.6315, lng: 77.2167 }
    },
    {
      area: "India Gate",
      count: 218,
      density: "Medium", 
      safetyLevel: "Excellent",
      alerts: 0,
      coordinates: { lat: 28.6129, lng: 77.2295 }
    },
    {
      area: "Red Fort",
      count: 156,
      density: "High",
      safetyLevel: "Good",
      alerts: 1,
      coordinates: { lat: 28.6562, lng: 77.2410 }
    },
    {
      area: "Karol Bagh",
      count: 89,
      density: "Low",
      safetyLevel: "Caution",
      alerts: 3,
      coordinates: { lat: 28.6519, lng: 77.1909 }
    }
  ]);

  const [recentIncidents] = useState([
    {
      id: "INC-2024-001",
      type: "Emergency Alert",
      location: "Khan Market, Delhi",
      time: "14:32",
      status: "Resolved",
      touristId: "TID-2024-IND-789456123",
      description: "Tourist reported suspicious activity",
      priority: "Medium"
    },
    {
      id: "INC-2024-002",
      type: "Missing Person",
      location: "Chandni Chowk, Delhi", 
      time: "13:15",
      status: "Active",
      touristId: "TID-2024-USA-456789012",
      description: "Tourist overdue from scheduled check-in",
      priority: "High"
    },
    {
      id: "INC-2024-003",
      type: "Scam Report",
      location: "Connaught Place, Delhi",
      time: "12:48",
      status: "Under Investigation",
      touristId: "TID-2024-UK-123456789",
      description: "Reported fake guide scam attempt",
      priority: "Low"
    }
  ]);

  const [aiAlerts] = useState([
    {
      id: 1,
      type: "Anomaly Detection",
      severity: "High",
      description: "Unusual cluster formation detected in Paharganj area",
      time: "2 mins ago",
      action: "Dispatch patrol unit"
    },
    {
      id: 2,
      type: "Predictive Alert", 
      severity: "Medium",
      description: "Increased scam risk predicted for evening hours at CP",
      time: "15 mins ago",
      action: "Deploy additional tourist police"
    },
    {
      id: 3,
      type: "Inactivity Alert",
      severity: "Medium", 
      description: "3 tourists haven't checked in for over 6 hours",
      time: "22 mins ago",
      action: "Initiate welfare check"
    }
  ]);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "High": return "bg-destructive text-destructive-foreground";
      case "Medium": return "bg-warning text-warning-foreground";
      case "Low": return "bg-primary text-primary-foreground";
      default: return "bg-secondary text-secondary-foreground";
    }
  };

  const getSafetyLevelColor = (level: string) => {
    switch (level) {
      case "Excellent": return "text-safety";
      case "Good": return "text-primary";
      case "Caution": return "text-warning";
      case "Alert": return "text-destructive";
      default: return "text-muted-foreground";
    }
  };

  const handleViewTouristProfile = (touristId: string) => {
    toast({
      title: "👤 Tourist Profile",
      description: `Opening detailed profile for ${touristId}`,
    });
  };

  const handleGenerateReport = () => {
    toast({
      title: "📊 Report Generated",
      description: "Comprehensive safety report has been generated and downloaded.",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <BackNavigation title="Authority Dashboard" />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-primary text-primary-foreground p-4 rounded-full mr-4">
              <Settings className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Authority Dashboard</h1>
              <p className="text-muted-foreground">Real-time tourist monitoring and incident management</p>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{realTimeStats.activeTourists}</div>
              <div className="text-xs text-muted-foreground">Active Tourists</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-emergency">{realTimeStats.emergencyAlerts}</div>
              <div className="text-xs text-muted-foreground">Emergency Alerts</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-safety">{realTimeStats.missingPersons}</div>
              <div className="text-xs text-muted-foreground">Missing Persons</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-warning">{realTimeStats.safeZoneViolations}</div>
              <div className="text-xs text-muted-foreground">Zone Violations</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-accent">{realTimeStats.avgResponseTime}</div>
              <div className="text-xs text-muted-foreground">Avg Response</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Button onClick={handleGenerateReport} size="sm" className="w-full">
                <Download className="h-3 w-3 mr-2" />
                Export Report
              </Button>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="monitoring" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="monitoring">Live Monitoring</TabsTrigger>
            <TabsTrigger value="incidents">Incidents</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="alerts">AI Alerts</TabsTrigger>
          </TabsList>

          {/* Live Monitoring Tab */}
          <TabsContent value="monitoring" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Tourist Heatmap */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5" />
                    Tourist Heatmap
                  </CardTitle>
                  <CardDescription>Real-time tourist cluster monitoring</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {touristClusters.map((cluster, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg">
                        <div>
                          <h4 className="font-medium">{cluster.area}</h4>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span>{cluster.count} tourists</span>
                            <span className={getSafetyLevelColor(cluster.safetyLevel)}>
                              {cluster.safetyLevel}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant={cluster.alerts > 0 ? "destructive" : "secondary"}>
                            {cluster.alerts} alerts
                          </Badge>
                          <div className="text-xs text-muted-foreground mt-1">
                            {cluster.density} density
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Search & Filter */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Search className="h-5 w-5" />
                    Tourist Lookup
                  </CardTitle>
                  <CardDescription>Search and filter tourist records</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Search by Tourist ID, name, or location..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="flex-1"
                    />
                    <Button variant="outline" size="icon">
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Filter className="h-3 w-3 mr-2" />
                      Filter by Status
                    </Button>
                    <Button variant="outline" size="sm">
                      <MapPin className="h-3 w-3 mr-2" />
                      Filter by Location
                    </Button>
                  </div>
                  <div className="space-y-2">
                    <div className="p-3 border border-border rounded-lg">
                      <div className="font-medium">TID-2024-IND-789456123</div>
                      <div className="text-sm text-muted-foreground">Rahul Sharma • Last seen: Connaught Place</div>
                      <Button size="sm" className="mt-2" onClick={() => handleViewTouristProfile("TID-2024-IND-789456123")}>
                        <Eye className="h-3 w-3 mr-2" />
                        View Profile
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Incidents Tab */}
          <TabsContent value="incidents" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Recent Incidents
                </CardTitle>
                <CardDescription>
                  Latest incidents and emergency responses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentIncidents.map((incident) => (
                    <div key={incident.id} className="p-4 border border-border rounded-lg">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-medium">{incident.type}</h4>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {incident.location}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {incident.time}
                            </span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Badge className={getPriorityColor(incident.priority)}>
                            {incident.priority}
                          </Badge>
                          <Badge variant={incident.status === "Resolved" ? "secondary" : "destructive"}>
                            {incident.status}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{incident.description}</p>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-3 w-3 mr-2" />
                          View Details
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleViewTouristProfile(incident.touristId)}>
                          <Users className="h-3 w-3 mr-2" />
                          Tourist Profile
                        </Button>
                        <Button size="sm" variant="outline">
                          <FileText className="h-3 w-3 mr-2" />
                          Generate E-FIR
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Safety Trends
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-safety">↑ 12%</div>
                      <div className="text-sm text-muted-foreground">Safety Score Improvement</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary">↓ 23%</div>
                      <div className="text-sm text-muted-foreground">Incident Reduction</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-accent">↑ 34%</div>
                      <div className="text-sm text-muted-foreground">Tourist Satisfaction</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Hotspot Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {realTimeStats.hotspotAreas.map((area, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span>{area}</span>
                        <Badge variant="secondary">{Math.floor(Math.random() * 300 + 100)} visitors</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* AI Alerts Tab */}
          <TabsContent value="alerts" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  AI-Generated Alerts
                </CardTitle>
                <CardDescription>
                  Machine learning powered anomaly detection and predictive alerts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aiAlerts.map((alert) => (
                    <div key={alert.id} className="p-4 border border-border rounded-lg">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-medium">{alert.type}</h4>
                          <p className="text-sm text-muted-foreground mt-1">{alert.description}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Clock className="h-3 w-3 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">{alert.time}</span>
                          </div>
                        </div>
                        <Badge className={alert.severity === "High" ? "bg-destructive text-destructive-foreground" : "bg-warning text-warning-foreground"}>
                          {alert.severity}
                        </Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm">
                          <Shield className="h-3 w-3 mr-2" />
                          {alert.action}
                        </Button>
                        <Button size="sm" variant="outline">
                          <Eye className="h-3 w-3 mr-2" />
                          View Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Floating Panic Button */}
      <PanicButton floating />
    </div>
  );
};

export default AuthorityDashboard;