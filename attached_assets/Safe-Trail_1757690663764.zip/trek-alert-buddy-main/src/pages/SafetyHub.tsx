import React, { useState } from "react";
import { BackNavigation } from "@/components/Navigation";
import { PanicButton } from "@/components/PanicButton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Shield,
  MapPin,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Clock,
  Users,
  Phone,
  Building,
  Navigation,
  Star,
} from "lucide-react";

const SafetyHub = () => {
  const [safetyScore] = useState(87);
  const [currentLocation] = useState("Connaught Place, New Delhi");
  
  const [geoFenceAlerts] = useState([
    {
      id: 1,
      zone: "Restricted Military Area",
      distance: "500m ahead",
      severity: "high",
      action: "Reroute immediately",
      type: "restricted"
    },
    {
      id: 2,
      zone: "High Crime Rate Area",
      distance: "2km north",
      severity: "medium",
      action: "Exercise caution",
      type: "caution"
    },
    {
      id: 3,
      zone: "Tourist Safe Zone",
      distance: "Current location",
      severity: "safe",
      action: "You're in a safe area",
      type: "safe"
    }
  ]);

  const [emergencyServices] = useState([
    {
      name: "Delhi Police Control Room",
      phone: "100",
      distance: "1.2 km",
      rating: 4.3,
      verified: true,
      type: "police"
    },
    {
      name: "AIIMS Emergency",
      phone: "1066",
      distance: "2.8 km", 
      rating: 4.7,
      verified: true,
      type: "medical"
    },
    {
      name: "Fire Brigade Station",
      phone: "101",
      distance: "800m",
      rating: 4.1,
      verified: true,
      type: "fire"
    },
    {
      name: "Tourist Helpline Delhi",
      phone: "1363",
      distance: "N/A",
      rating: 4.0,
      verified: true,
      type: "tourist"
    }
  ]);

  const [safetyTrends] = useState([
    { area: "Connaught Place", score: 92, trend: "up", change: "+5%" },
    { area: "India Gate", score: 89, trend: "up", change: "+2%" },
    { area: "Karol Bagh", score: 76, trend: "down", change: "-3%" },
    { area: "Chandni Chowk", score: 71, trend: "down", change: "-7%" },
  ]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high": return "bg-destructive text-destructive-foreground";
      case "medium": return "bg-warning text-warning-foreground";
      case "safe": return "bg-safety text-safety-foreground";
      default: return "bg-secondary text-secondary-foreground";
    }
  };

  const getServiceIcon = (type: string) => {
    switch (type) {
      case "police": return "🚔";
      case "medical": return "🚑";
      case "fire": return "🚒";
      case "tourist": return "🗺️";
      default: return "📞";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <BackNavigation title="Travel Safety Hub" />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-safety text-safety-foreground p-4 rounded-full mr-4">
              <Shield className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Travel Safety Hub</h1>
              <p className="text-muted-foreground">AI-powered safety insights and real-time alerts</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Safety Score */}
            <Card className="border-safety/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-safety" />
                  Current Safety Score
                </CardTitle>
                <CardDescription>
                  AI-calculated safety rating for your current location
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                    <span className="font-medium">{currentLocation}</span>
                  </div>
                  <Badge className="bg-safety text-safety-foreground text-lg px-4 py-2">
                    {safetyScore}/100
                  </Badge>
                </div>
                <Progress value={safetyScore} className="h-3 mb-4" />
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">24/7</div>
                    <div className="text-sm text-muted-foreground">Monitoring</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-safety">12</div>
                    <div className="text-sm text-muted-foreground">Safe Zones</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-warning">3</div>
                    <div className="text-sm text-muted-foreground">Alerts</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">847</div>
                    <div className="text-sm text-muted-foreground">Travelers</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Geo-fence Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Navigation className="h-5 w-5" />
                  Geo-fence Alerts
                </CardTitle>
                <CardDescription>
                  Real-time location-based safety notifications
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {geoFenceAlerts.map((alert) => (
                    <div key={alert.id} className="flex items-start gap-4 p-4 border border-border rounded-lg">
                      <div className="mt-1">
                        {alert.type === "restricted" && <AlertTriangle className="h-5 w-5 text-destructive" />}
                        {alert.type === "caution" && <AlertTriangle className="h-5 w-5 text-warning" />}
                        {alert.type === "safe" && <Shield className="h-5 w-5 text-safety" />}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">{alert.zone}</h4>
                          <Badge className={getSeverityColor(alert.severity)}>
                            {alert.severity}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">{alert.distance}</p>
                        <p className="text-sm font-medium">{alert.action}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Area Safety Trends */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Area Safety Trends
                </CardTitle>
                <CardDescription>
                  Safety scores and trends for nearby areas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {safetyTrends.map((trend, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg">
                      <div className="flex items-center gap-3">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{trend.area}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge variant="outline">{trend.score}/100</Badge>
                        <div className="flex items-center gap-1">
                          {trend.trend === "up" ? (
                            <TrendingUp className="h-4 w-4 text-safety" />
                          ) : (
                            <TrendingDown className="h-4 w-4 text-destructive" />
                          )}
                          <span className={`text-sm ${trend.trend === "up" ? "text-safety" : "text-destructive"}`}>
                            {trend.change}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Emergency Services Directory */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone className="h-5 w-5" />
                  Emergency Services
                </CardTitle>
                <CardDescription>
                  Verified emergency contacts near you
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {emergencyServices.map((service, index) => (
                    <div key={index} className="p-3 border border-border rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span>{getServiceIcon(service.type)}</span>
                          <div>
                            <h4 className="font-medium text-sm">{service.name}</h4>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <span>{service.distance}</span>
                              {service.verified && <Badge variant="outline" className="text-xs px-1">Verified</Badge>}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-3 w-3 text-warning fill-current" />
                          <span className="text-xs">{service.rating}</span>
                        </div>
                      </div>
                      <Button size="sm" className="w-full">
                        <Phone className="h-3 w-3 mr-2" />
                        Call {service.phone}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Safety Features */}
            <Card>
              <CardHeader>
                <CardTitle>Safety Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-primary" />
                    Live Location
                  </span>
                  <Badge className="bg-safety text-safety-foreground">Active</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-primary" />
                    Geo-fencing
                  </span>
                  <Badge className="bg-safety text-safety-foreground">Active</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-primary" />
                    Community Alerts
                  </span>
                  <Badge className="bg-primary text-primary-foreground">Enabled</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-primary" />
                    Check-in Reminders
                  </span>
                  <Badge variant="secondary">Every 2 hours</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <MapPin className="h-4 w-4 mr-2" />
                  Report Unsafe Area
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="h-4 w-4 mr-2" />
                  Find Nearby Travelers
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Building className="h-4 w-4 mr-2" />
                  Locate Safe Facilities
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Floating Panic Button */}
      <PanicButton floating />
    </div>
  );
};

export default SafetyHub;