import React from "react";
import { Link } from "react-router-dom";
import { Navigation } from "@/components/Navigation";
import { PanicButton } from "@/components/PanicButton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import heroImage from "@/assets/hero-safety.jpg";
import {
  Shield,
  Users,
  CreditCard,
  AlertTriangle,
  Bot,
  MapPin,
  Clock,
  TrendingUp,
} from "lucide-react";

const dashboardItems = [
  {
    title: "Tourist Profile",
    description: "Manage your travel information and emergency contacts",
    icon: Users,
    href: "/profile",
    color: "bg-primary",
    urgent: false,
  },
  {
    title: "Digital Tourist ID",
    description: "Your blockchain-based travel identification",
    icon: CreditCard,
    href: "/digital-id",
    color: "bg-accent",
    urgent: false,
  },
  {
    title: "Travel Safety Hub",
    description: "AI-powered safety insights and geo-fence alerts",
    icon: Shield,
    href: "/safety-hub",
    color: "bg-safety",
    urgent: false,
  },
  {
    title: "Scam Awareness",
    description: "Local scam alerts and verified price information",
    icon: AlertTriangle,
    href: "/scam-awareness",
    color: "bg-warning",
    urgent: true,
  },
  {
    title: "AI Travel Assistant",
    description: "Get personalized safety recommendations",
    icon: Bot,
    href: "/ai-assistant",
    color: "bg-primary",
    urgent: false,
  },
  {
    title: "Traveler Connect",
    description: "Connect with fellow travelers for safety",
    icon: Users,
    href: "/traveler-connect",
    color: "bg-accent",
    urgent: false,
  },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section 
        className="relative bg-gradient-to-br from-primary to-primary-dark text-primary-foreground py-24 bg-cover bg-center"
        style={{ backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.4)), url(${heroImage})` }}
      >
        <div className="container mx-auto px-4 text-center relative z-10">
          <h1 className="text-5xl md:text-7xl font-bold mb-8 drop-shadow-lg">
            🛡️ Smart Tourist Safety Platform
          </h1>
          <p className="text-xl md:text-3xl mb-12 opacity-95 max-w-4xl mx-auto leading-relaxed">
            Your AI-powered safety companion for worry-free travel with emergency response, 
            real-time alerts, and community protection
          </p>
          <div className="flex flex-wrap items-center justify-center gap-6 mb-8">
            <Badge variant="secondary" className="text-lg px-6 py-3 bg-white/20 backdrop-blur-sm border-white/30">
              <MapPin className="w-5 h-5 mr-3" />
              GPS Protected
            </Badge>
            <Badge variant="secondary" className="text-lg px-6 py-3 bg-white/20 backdrop-blur-sm border-white/30">
              <Clock className="w-5 h-5 mr-3" />
              24/7 Monitoring
            </Badge>
            <Badge variant="secondary" className="text-lg px-6 py-3 bg-white/20 backdrop-blur-sm border-white/30">
              <Shield className="w-5 h-5 mr-3" />
              AI-Powered Alerts
            </Badge>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/emergency">
              <Button size="lg" className="bg-emergency hover:bg-emergency/90 text-emergency-foreground text-lg px-8 py-4">
                🚨 Emergency Panel
              </Button>
            </Link>
            <Link to="/profile">
              <Button size="lg" variant="secondary" className="text-lg px-8 py-4 bg-white/20 backdrop-blur-sm border-white/30 hover:bg-white/30">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-background/20 to-transparent"></div>
      </section>

      {/* Quick Stats */}
      <section className="py-8 border-b border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-safety mb-2">98.7%</div>
                <div className="text-muted-foreground">Safety Score</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-primary mb-2">1,247</div>
                <div className="text-muted-foreground">Active Travelers</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-warning mb-2">23</div>
                <div className="text-muted-foreground">Scam Alerts Today</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Dashboard Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Safety Dashboard</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {dashboardItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.title} to={item.href}>
                  <Card className="h-full hover:shadow-lg transition-all duration-300 border-2 hover:border-primary/20">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className={`${item.color} text-white p-3 rounded-lg`}>
                          <Icon className="h-6 w-6" />
                        </div>
                        {item.urgent && (
                          <Badge variant="destructive" className="text-xs">
                            Important
                          </Badge>
                        )}
                      </div>
                      <CardTitle className="text-xl">{item.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-base">
                        {item.description}
                      </CardDescription>
                      <Button className="w-full mt-4" variant="outline">
                        Open {item.title}
                      </Button>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Emergency Contact Banner */}
      <section className="bg-emergency/5 border-t border-emergency/20 py-8">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-xl font-bold mb-4 text-emergency">
            🚨 Need Immediate Help?
          </h3>
          <p className="text-muted-foreground mb-6">
            Use the emergency button for instant alerts to police, medical services, and your emergency contacts
          </p>
          <Link to="/emergency">
            <Button className="bg-emergency hover:bg-emergency/90 text-emergency-foreground">
              View Emergency Panel
            </Button>
          </Link>
        </div>
      </section>

      {/* Floating Panic Button */}
      <PanicButton floating />
    </div>
  );
};

export default Index;