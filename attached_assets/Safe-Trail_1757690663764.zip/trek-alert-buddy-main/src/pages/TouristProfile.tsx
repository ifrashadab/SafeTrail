import React, { useState } from "react";
import { BackNavigation } from "@/components/Navigation";
import { PanicButton } from "@/components/PanicButton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  User,
  MapPin,
  Phone,
  Mail,
  Calendar,
  Plane,
  Train,
  Car,
  Building,
  Globe,
  Heart,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

const TouristProfile = () => {
  const [profile, setProfile] = useState({
    name: "",
    email: "",
    phone: "",
    nationality: "",
    travelerType: "",
    emergencyContact1: { name: "", phone: "", relation: "" },
    emergencyContact2: { name: "", phone: "", relation: "" },
    accommodation: "",
    itinerary: "",
    medicalConditions: "",
    languages: "",
  });

  const [isEditing, setIsEditing] = useState(true);

  const travelerTypes = [
    { value: "international", label: "International Tourist", icon: Plane },
    { value: "domestic", label: "Domestic Tourist", icon: Train },
    { value: "business", label: "Business Traveler", icon: Building },
    { value: "road", label: "Road Trip", icon: Car },
  ];

  const handleSaveProfile = () => {
    toast({
      title: "✅ Profile Updated",
      description: "Your tourist profile has been saved successfully.",
    });
    setIsEditing(false);
  };

  const getPersonalizedTips = () => {
    const tips = [];
    if (profile.travelerType === "international") {
      tips.push("Keep your passport and visa documents secure");
      tips.push("Register with your embassy");
    }
    if (profile.travelerType === "road") {
      tips.push("Ensure your vehicle documents are updated");
      tips.push("Keep emergency roadside assistance numbers handy");
    }
    if (profile.medicalConditions) {
      tips.push("Carry necessary medications and medical certificates");
    }
    return tips;
  };

  return (
    <div className="min-h-screen bg-background">
      <BackNavigation title="Tourist Profile" />
      
      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-primary text-primary-foreground p-4 rounded-full mr-4">
              <User className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Tourist Profile</h1>
              <p className="text-muted-foreground">Manage your travel information and emergency contacts</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Profile Form */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Personal Information
                </CardTitle>
                <CardDescription>
                  Basic information required for emergency response
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      placeholder="Enter your full name"
                      value={profile.name}
                      onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                      disabled={!isEditing}
                    />
                  </div>
                  <div>
                    <Label htmlFor="nationality">Nationality *</Label>
                    <Input
                      id="nationality"
                      placeholder="e.g., Indian, American, etc."
                      value={profile.nationality}
                      onChange={(e) => setProfile({ ...profile, nationality: e.target.value })}
                      disabled={!isEditing}
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your.email@example.com"
                      value={profile.email}
                      onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                      disabled={!isEditing}
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      placeholder="+91 XXXXXXXXXX"
                      value={profile.phone}
                      onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                      disabled={!isEditing}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="travelerType">Traveler Type *</Label>
                  <Select
                    value={profile.travelerType}
                    onValueChange={(value) => setProfile({ ...profile, travelerType: value })}
                    disabled={!isEditing}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select traveler type" />
                    </SelectTrigger>
                    <SelectContent>
                      {travelerTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Emergency Contacts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone className="h-5 w-5" />
                  Emergency Contacts
                </CardTitle>
                <CardDescription>
                  People to contact in case of emergency (minimum 2 required)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {[1, 2].map((num) => (
                  <div key={num} className="border border-border p-4 rounded-lg">
                    <h4 className="font-medium mb-3">Emergency Contact {num}</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor={`contact${num}Name`}>Name *</Label>
                        <Input
                          id={`contact${num}Name`}
                          placeholder="Contact name"
                          value={(profile[`emergencyContact${num}` as keyof typeof profile] as any).name || ""}
                          onChange={(e) => setProfile({
                            ...profile,
                            [`emergencyContact${num}`]: {
                              ...(profile[`emergencyContact${num}` as keyof typeof profile] as any),
                              name: e.target.value
                            }
                          })}
                          disabled={!isEditing}
                        />
                      </div>
                      <div>
                        <Label htmlFor={`contact${num}Phone`}>Phone Number *</Label>
                        <Input
                          id={`contact${num}Phone`}
                          placeholder="+91 XXXXXXXXXX"
                          value={(profile[`emergencyContact${num}` as keyof typeof profile] as any).phone || ""}
                          onChange={(e) => setProfile({
                            ...profile,
                            [`emergencyContact${num}`]: {
                              ...(profile[`emergencyContact${num}` as keyof typeof profile] as any),
                              phone: e.target.value
                            }
                          })}
                          disabled={!isEditing}
                        />
                      </div>
                      <div>
                        <Label htmlFor={`contact${num}Relation`}>Relationship</Label>
                        <Input
                          id={`contact${num}Relation`}
                          placeholder="e.g., Father, Friend"
                          value={(profile[`emergencyContact${num}` as keyof typeof profile] as any).relation || ""}
                          onChange={(e) => setProfile({
                            ...profile,
                            [`emergencyContact${num}`]: {
                              ...(profile[`emergencyContact${num}` as keyof typeof profile] as any),
                              relation: e.target.value
                            }
                          })}
                          disabled={!isEditing}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Travel Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Travel Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="accommodation">Accommodation Details</Label>
                  <Input
                    id="accommodation"
                    placeholder="Hotel name, address, or stay details"
                    value={profile.accommodation}
                    onChange={(e) => setProfile({ ...profile, accommodation: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
                <div>
                  <Label htmlFor="itinerary">Travel Itinerary</Label>
                  <Textarea
                    id="itinerary"
                    placeholder="Brief description of your travel plans..."
                    value={profile.itinerary}
                    onChange={(e) => setProfile({ ...profile, itinerary: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
                <div>
                  <Label htmlFor="medicalConditions">Medical Conditions</Label>
                  <Input
                    id="medicalConditions"
                    placeholder="Any medical conditions or allergies"
                    value={profile.medicalConditions}
                    onChange={(e) => setProfile({ ...profile, medicalConditions: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
                <div>
                  <Label htmlFor="languages">Languages Spoken</Label>
                  <Input
                    id="languages"
                    placeholder="e.g., English, Hindi, Spanish"
                    value={profile.languages}
                    onChange={(e) => setProfile({ ...profile, languages: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-4">
              {isEditing ? (
                <>
                  <Button onClick={handleSaveProfile} className="flex-1">
                    Save Profile
                  </Button>
                  <Button variant="outline" onClick={() => setIsEditing(false)} className="flex-1">
                    Cancel
                  </Button>
                </>
              ) : (
                <Button onClick={() => setIsEditing(true)} variant="outline" className="flex-1">
                  Edit Profile
                </Button>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Profile Status */}
            <Card>
              <CardHeader>
                <CardTitle>Profile Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Profile Completion</span>
                  <Badge className="bg-safety text-safety-foreground">85%</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Emergency Contacts</span>
                  <Badge variant="secondary">2/2</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Travel Type</span>
                  <Badge className="bg-primary text-primary-foreground">
                    {profile.travelerType || "Not Set"}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Personalized Safety Tips */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5" />
                  Safety Tips for You
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {getPersonalizedTips().map((tip, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <Badge variant="secondary" className="w-6 h-6 rounded-full flex items-center justify-center text-xs mt-1">
                        {index + 1}
                      </Badge>
                      <span className="text-sm">{tip}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Globe className="h-4 w-4 mr-2" />
                  Update Language Preferences
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Calendar className="h-4 w-4 mr-2" />
                  Set Travel Dates
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <MapPin className="h-4 w-4 mr-2" />
                  Share Location with Contacts
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Floating Panic Button */}
      <PanicButton floating />
    </div>
  );
};

export default TouristProfile;