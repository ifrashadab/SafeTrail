import React from "react";
import { Link, useLocation } from "react-router-dom";
import { 
  Home, 
  User, 
  CreditCard, 
  Shield, 
  AlertTriangle, 
  Bot, 
  Users, 
  Settings,
  ArrowLeft 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Profile", href: "/profile", icon: User },
  { name: "Digital ID", href: "/digital-id", icon: CreditCard },
  { name: "Safety Hub", href: "/safety-hub", icon: Shield },
  { name: "Scam Awareness", href: "/scam-awareness", icon: AlertTriangle },
  { name: "AI Assistant", href: "/ai-assistant", icon: Bot },
  { name: "Traveler Connect", href: "/traveler-connect", icon: Users },
  { name: "Authority Dashboard", href: "/authority-dashboard", icon: Settings },
];

export const Navigation = () => {
  const location = useLocation();

  return (
    <nav className="bg-card border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <Link to="/" className="text-xl font-bold text-primary">
              🛡️ Tourist Safety
            </Link>
          </div>
          <div className="hidden md:flex items-center space-x-2">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.name} to={item.href}>
                  <Button
                    variant={location.pathname === item.href ? "default" : "ghost"}
                    size="sm"
                    className="flex items-center gap-2"
                  >
                    <Icon className="h-4 w-4" />
                    {item.name}
                  </Button>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
};

export const BackNavigation = ({ title }: { title: string }) => {
  return (
    <div className="bg-card border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center h-16">
          <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="ml-4 text-lg font-semibold">{title}</h1>
        </div>
      </div>
    </div>
  );
};