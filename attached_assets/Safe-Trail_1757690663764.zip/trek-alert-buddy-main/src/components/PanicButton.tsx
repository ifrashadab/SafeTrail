import React, { useState } from "react";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";

interface PanicButtonProps {
  className?: string;
  floating?: boolean;
}

export const PanicButton = ({ className, floating = false }: PanicButtonProps) => {
  const [showConfirm, setShowConfirm] = useState(false);

  const handlePanicPress = () => {
    setShowConfirm(true);
  };

  const handleConfirmEmergency = () => {
    // Emergency alert logic would go here
    toast({
      title: "🚨 Emergency Alert Sent!",
      description: "Police, medical services, and emergency contacts have been notified. Help is on the way.",
      variant: "destructive",
    });
    setShowConfirm(false);
  };

  const baseClasses = floating
    ? "fixed bottom-6 right-6 z-50 h-16 w-16 rounded-full animate-emergency-pulse"
    : "h-12 w-12 rounded-full animate-emergency-glow";

  return (
    <>
      <Button
        onClick={handlePanicPress}
        className={`
          bg-emergency hover:bg-emergency/90 text-emergency-foreground
          border-2 border-emergency-foreground/20
          ${baseClasses} ${className}
        `}
        size="icon"
      >
        <AlertTriangle className="h-6 w-6" />
      </Button>

      <AlertDialog open={showConfirm} onOpenChange={setShowConfirm}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-center text-xl font-bold text-emergency">
              🚨 Emergency Alert
            </AlertDialogTitle>
            <AlertDialogDescription className="text-center text-lg">
              Are you in immediate danger and need emergency assistance?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex gap-4">
            <AlertDialogCancel className="flex-1">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmEmergency}
              className="flex-1 bg-emergency hover:bg-emergency/90 text-emergency-foreground"
            >
              Yes, Send Alert!
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};