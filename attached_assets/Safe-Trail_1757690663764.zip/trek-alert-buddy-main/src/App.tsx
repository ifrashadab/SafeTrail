import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import EmergencyPanel from "./pages/EmergencyPanel";
import TouristProfile from "./pages/TouristProfile";
import DigitalTouristID from "./pages/DigitalTouristID";
import SafetyHub from "./pages/SafetyHub";
import ScamAwareness from "./pages/ScamAwareness";
import AIAssistant from "./pages/AIAssistant";
import TravelerConnect from "./pages/TravelerConnect";
import AuthorityDashboard from "./pages/AuthorityDashboard";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/emergency" element={<EmergencyPanel />} />
          <Route path="/profile" element={<TouristProfile />} />
          <Route path="/digital-id" element={<DigitalTouristID />} />
          <Route path="/safety-hub" element={<SafetyHub />} />
          <Route path="/scam-awareness" element={<ScamAwareness />} />
          <Route path="/ai-assistant" element={<AIAssistant />} />
          <Route path="/traveler-connect" element={<TravelerConnect />} />
          <Route path="/authority-dashboard" element={<AuthorityDashboard />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
